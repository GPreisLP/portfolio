<?php include 'header.php' ?>
<div class="content">
	<div class="services">
		<h3>Our Services</h3>
		<div class="services-top">
			<p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.</p>
		</div>
		<div class="services-nav">
				<ul>
					 <li>24 hrs Generator Backup</li>
					 <li>Free Internet Service</li>	
					 <li>Medical Services</li>	
					 <li>Govt.approved</li>
					 <li>Free Parking</li>	
					 <li>Cash Advance-credit Card</li>
					 <li>Fax</li>
                     <li>Package Tours</li>
                     <li>Free Accomodation for Drivers</li>
                     <li>24 hrs hot and cold water</li>
                     <li>T.V in all rooms</li>
                     <li>Laundry Service</li>
                     <li>Lift is available in all floors</li>
                     <li>Rooms are provided with good furniture</li>
               </ul>
	   </div>
  	</div>
 </div>
</div>
</div>
<div class="content-bottom">
  <div class="wrap">
	 <div class="bottom-gallery">			
			<div class="bottom-image">
				<img src="images/pic.jpg">
			</div>
			<div class="bottom-image">
				<img src="images/pic4.jpg">
			</div>
			<div class="bottom-image">
				<img src="images/pic10.jpg">
			</div>
			<div class="bottom-image1">
				<img src="images/pic7.jpg">
			</div>
		    <div class="clear"></div>
   </div>
 </div>
</div>
<?php include 'footer.php'?>