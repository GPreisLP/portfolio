<?php include 'header.php';?>
<div class="content">
	<div class="food$beverage"> 
		 <div class="content-top">
		<div class="food-left">
				<div class="pic">
					<h2>Imagenes</h2>
				    <div class="sub-image">
				 		<a href="#"><img src="images/pic8.jpg"></a>
				 	</div>	
				 	
					<div class="sub-image">
				 		<a href="#"><img src="images/pic9.jpg"></a>
				 	</div>
				 	<div class="sub-image">
				 		<a href="#"><img src="images/pic11.jpg"></a>
				 	</div>	
				 	<div class="sub-image">
				 		<a href="#"><img src="images/pic12.jpg"></a>
				 	</div>	
				 	<div class="sub-image">
				 		<a href="#"><img src="images/pic13.jpg"></a>
				 	</div>	
				 	<div class="sub-image">
				 		<a href="#"><img src="images/pic14.jpg"></a>
				 	</div>	
				 	<div class="sub-image">
				 		<a href="#"><img src="images/pic15.jpg"></a>
				 	</div>	
				 	<div class="sub-image">
				 		<a href="#"><img src="images/pic16.jpg"></a>
				 	</div>	
				 	<div class="sub-image">
				 		<a href="#"><img src="images/pic6.jpg"></a>
				 	</div>	
				 	<div class="sub-image">
				 		<a href="#"><img src="images/pic19.jpg"></a>
				 	</div>		
					 <div class="clear"></div> 
		    </div>
	</div>
	<div class="food-right">
		<div class="sub-right">
			   <div class="sub1-image">
				   	<a href="#"><img src="images/pic21.jpg" /></a>
			  </div>
		</div>
	</div>
	<div class="clear"></div>
   </div>
  </div>
 </div>
</div>
</div>
<div class="content-bottom">
		<div class="wrap">
		  <div class="bottom-gallery">			
			<div class="bottom-image">
				<img src="images/pic.jpg">
			</div>
			<div class="bottom-image">
				<img src="images/pic4.jpg">
			</div>
			<div class="bottom-image">
				<img src="images/pic10.jpg">
			</div>
			<div class="bottom-image1">
				<img src="images/pic7.jpg">
			</div>
			<div class="clear"></div>
  </div>
 </div>
</div>
<?php include 'footer.php'?>
</html>